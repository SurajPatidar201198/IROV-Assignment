from django.shortcuts import render

# Create your views here.
import json

from .models import Person, get_cs_strings, get_b_strings, get_c_strings
from .forms import PersonForm

# Create your views here.

def personform_page(request):

    if request.method=='POST':
        form=PersonForm(request.POST)
        if form.is_valid():
            visibility = form.cleaned_data['visibility']
            method = form.cleaned_data['method']
            input_path = form.cleaned_data['path']
            output_path = form.cleaned_data['output']
            ip_cam= form.cleaned_data['ip_cam']
            print(input_path,output_path,ip_cam,visibility,method)

    context = {}
    personform = PersonForm()
    context['personform'] = personform

    cs_strings = get_cs_strings()
    b_strings = get_b_strings()
    c_strings = get_c_strings()

    json_cs_strings = json.dumps(cs_strings)
    json_b_strings = json.dumps(b_strings)
    json_c_strings = json.dumps(c_strings)

    context['json_cs_strings'] = json_cs_strings
    context['json_b_strings'] = json_b_strings
    context['json_c_strings'] = json_c_strings



    return render(request, 'contact.html', context)