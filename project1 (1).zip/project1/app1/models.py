from django.db import models
# Create your models here.

# visibility_value1 = '1'
# visibility_value2 = '2'
# visibility_value3 = '3'

Method1 = 'Method1'
Method2 = 'Method2'
Method3 = 'Method3'
Method4 = 'Method4'
Method5 = 'Method5'
Method6 = 'Method6'

# VISIBILITY_CHOICES = [
#     (visibility_value1, visibility_value1),
#     (visibility_value2, visibility_value2),
#     (visibility_value3, visibility_value3),
# ]

METHOD_CHOICES = [
    (Method1, Method1),
    (Method2, Method2),
    (Method3, Method3),
    (Method4, Method4),
    (Method5, Method5),
    (Method6, Method6),
]

def get_cs_strings():
    cs_strings = [
        Method1,
        Method2,
        Method3,
    ]

    return cs_strings


def get_b_strings():
    b_strings = [
        Method4,
        Method5,
    ]

    return b_strings

def get_c_strings():
    c_strings = [
        Method6,
    ]

    return c_strings

class Person(models.Model):
    path = models.FilePathField(path="app1/")
    output = models.FilePathField(path="app1/",allow_files=False, allow_folders=True)
    ip_cam = models.BooleanField()

    # id_visibility
    visibility = models.IntegerField()
    # id_method
    method = models.CharField(max_length=50, choices=METHOD_CHOICES)